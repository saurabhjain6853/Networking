//
//  ViewController.swift
//  Decodeble
//
//  Created by Subhash Sharma on 25/06/18.
//  Copyright © 2018 OctalSoftware. All rights reserved.
//

import Alamofire
import CodableAlamofire

class APIClient {
    @discardableResult
    private static func performRequest<T:Decodable>(route:APIRouter, decoder: JSONDecoder = JSONDecoder(), completion:@escaping (Result<T>)->Void) -> DataRequest {
        return Alamofire.request(route).responseDecodableObject(decoder: decoder, completionHandler: { (response:DataResponse<T>) in
            completion(response.result)
        })
    }
    
    static func login(parameter:[String:Any], completion:@escaping (Result<User>)->Void) {
        performRequest(route: APIRouter.login(parameter), completion: completion)
    }
    
    static func getArticles(completion:@escaping (Result<[Article]>)->Void) {
        let jsonDecoder = JSONDecoder()
        jsonDecoder.dateDecodingStrategy = .formatted(.articleDateFormatter)
        performRequest(route: APIRouter.articles, decoder: jsonDecoder, completion: completion)
    }
}

