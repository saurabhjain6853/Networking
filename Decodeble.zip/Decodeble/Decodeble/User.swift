//
//  User.swift
//  Decodeble
//
//  Created by Subhash Sharma on 26/07/18.
//  Copyright © 2018 OctalSoftware. All rights reserved.
//

import Foundation

struct User:Codable {
    let firstName: String
    let lastName: String
    let email: String
    let image: URL
}
