//
//  ViewController.swift
//  Decodeble
//
//  Created by Subhash Sharma on 25/06/18.
//  Copyright © 2018 OctalSoftware. All rights reserved.
//

import UIKit

struct Course:Decodable {
    let id:Int
    let name:String
    let link:String
    let imageUrl:String
    let number_of_lessons:Int
}

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
//        let jsonString = "http://api.letsbuildthatapp.com/jsondecodable/courses"
//        guard let url = URL(string: jsonString) else {
//            return
//        }
//
//        URLSession.shared.dataTask(with: url) { (data, response, err) in
//            guard let data = data else {return}
//
//            do {
//                let courses = try JSONDecoder().decode([Course].self, from: data)
//                print(courses[1].name)
//            }catch {
//
//            }
//        }.resume()
        
        // Test getArticles request
        APIClient.getArticles{ result in
            switch result {
            case .success(let articles):
                print("_____________________________")
                print("Article:\(articles)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
        let parameterDic = [K.APIParameterKey.email:"test@gmail.com",
                            K.APIParameterKey.password:"myPassword"]
        // Test Login request
        APIClient.login(parameter: parameterDic) { result in
            switch result {
            case .success(let user):
                print("_____________________________")
                print("User:\(user)")
            case .failure(let error):
                print(error.localizedDescription)
            }
        }

    }

}

